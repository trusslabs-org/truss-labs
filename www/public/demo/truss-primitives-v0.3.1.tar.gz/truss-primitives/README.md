# Truss Primitives

This package contains the core CLI tools for the Truss Audit substrate.

## Usage

1. Add the current directory to your PATH or run directly:
   ./truss --help

2. Run the sample pipe:
   ./truss trap add --on ON_RETRY --action ACTION_HALT
   cat hooks.jsonl | ./truss trace translate | ./truss trace analyze --json --flag FLAG_CIRCULAR_REASONING | ./truss trap run

3. Verify the sample receipts:
   ./truss receipt verify examples/receipts

License: Apache 2.0
