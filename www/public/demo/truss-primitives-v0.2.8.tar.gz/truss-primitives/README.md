# Truss Primitives

This package contains the core CLI tools for the Truss Audit substrate.

## Usage

1. Add the current directory to your PATH or run directly:
   ./truss --help

2. Run the sample pipe:
   cat hooks.jsonl | ./truss translate | ./truss analyze --json --flag FLAG_CIRCULAR_REASONING | ./truss trap run

License: Apache 2.0
