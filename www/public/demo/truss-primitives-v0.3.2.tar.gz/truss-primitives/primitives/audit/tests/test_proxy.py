"""End-to-end tests for primitives.audit.proxy.

Exercises the full pipeline classifier → policy_engine → receipt_writer
against the two shipped example policies, using a deterministic
StubLLMClient so tests don't need network or API keys.
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from fastapi.testclient import TestClient  # noqa: E402

from audit.classifier import Classifier  # noqa: E402
from audit.policy_loader import load_policies  # noqa: E402
from audit.proxy import StubLLMClient, create_app  # noqa: E402


_REPO_ROOT = Path(__file__).resolve().parents[3]
PHI_TAXONOMY = _REPO_ROOT / "primitives" / "audit" / "taxonomies" / "phi.yaml"
EXAMPLE_POLICIES_DIR = _REPO_ROOT / "examples" / "policies"


def _actor() -> dict:
    return {"user_id": "alice@example.com", "user_role": "clinician"}


class ProxyBase(unittest.TestCase):
    """Boots an app with the shipped example policies + a stub LLM client."""

    canned_response: str = "OK"

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.receipts_dir = Path(self.tmp.name)
        policy_set = load_policies(EXAMPLE_POLICIES_DIR)
        classifiers = [Classifier.from_taxonomy_file(PHI_TAXONOMY)]
        self.client_stub = StubLLMClient(canned_response=self.canned_response)
        app = create_app(
            policy_set=policy_set,
            classifiers=classifiers,
            receipts_dir=self.receipts_dir,
            llm_client=self.client_stub,
        )
        self.client = TestClient(app)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _read_receipt(self, path_str: str) -> dict:
        return json.loads(Path(path_str).read_text())


# ---------------------------------------------------------------------------
# Block path: address in prompt → blocked, no LLM call, receipt records the block
# ---------------------------------------------------------------------------


class BlockPath(ProxyBase):
    canned_response = "should-never-be-returned"

    def test_address_in_prompt_blocks(self) -> None:
        resp = self.client.post(
            "/v1/chat",
            json={
                "prompt": "Patient lives at 1234 Main St.",
                "actor": _actor(),
                "destination": "external_vendor",
            },
        )
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["verdict"], "blocked")
        self.assertIn("Patient address detected", body["block_message"])
        self.assertIsNone(body["response"])

    def test_blocked_request_writes_receipt_with_block_decision(self) -> None:
        resp = self.client.post(
            "/v1/chat",
            json={
                "prompt": "Patient lives at 1234 Main St.",
                "actor": _actor(),
            },
        )
        receipt = self._read_receipt(resp.json()["receipt_path"])
        # Receipt has an empty response and exactly one prompt-phase block decision.
        self.assertEqual(receipt["response"]["text"], "")
        verdicts = [d["verdict"] for d in receipt["policy_decisions"]]
        self.assertIn("blocked", verdicts)
        # Block decision carries the policy_id of the example block policy.
        block_ids = [
            d["policy_id"] for d in receipt["policy_decisions"] if d["verdict"] == "blocked"
        ]
        self.assertIn("phi_block_address_in_external_prompt", block_ids)


# ---------------------------------------------------------------------------
# Redact path: DOB in response → response returned with [redacted] in place
# ---------------------------------------------------------------------------


class RedactPath(ProxyBase):
    # The stub returns this verbatim; the engine should redact the DOB span.
    canned_response = "DOB 1978-04-12 noted on chart."

    def test_dob_in_response_redacted(self) -> None:
        resp = self.client.post(
            "/v1/chat",
            json={
                "prompt": "Summarize the case note.",
                "actor": _actor(),
                "destination": "external_vendor",
            },
        )
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["verdict"], "redacted")
        self.assertIn("[redacted]", body["response"])
        self.assertNotIn("1978-04-12", body["response"])

    def test_redacted_response_receipt_carries_redaction(self) -> None:
        resp = self.client.post(
            "/v1/chat",
            json={
                "prompt": "Summarize the case note.",
                "actor": _actor(),
            },
        )
        receipt = self._read_receipt(resp.json()["receipt_path"])
        verdicts = [d["verdict"] for d in receipt["policy_decisions"]]
        self.assertIn("redacted", verdicts)
        redact = next(
            d for d in receipt["policy_decisions"] if d["verdict"] == "redacted"
        )
        self.assertEqual(redact["policy_id"], "phi_redact_dob_in_response")
        self.assertEqual(len(redact["redactions_applied"]), 1)
        self.assertEqual(redact["redactions_applied"][0]["location"], "response")


# ---------------------------------------------------------------------------
# Root routes
# ---------------------------------------------------------------------------


class RootRoute(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.receipts_dir = Path(self.tmp.name)
        self.demo_dir = Path(self.tmp.name) / "demo"
        self.demo_dir.mkdir()
        self.demo_html = self.demo_dir / "demo.html"
        self.demo_html.write_text("DEMO ENVIRONMENT for Truss Audit Proxy")

        policy_set = load_policies(EXAMPLE_POLICIES_DIR)
        classifiers = [Classifier.from_taxonomy_file(PHI_TAXONOMY)]
        app = create_app(
            policy_set=policy_set,
            classifiers=classifiers,
            receipts_dir=self.receipts_dir,
            llm_client=StubLLMClient(),
            demo_html_path=self.demo_html,
        )
        self.client = TestClient(app)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_root_serves_demo_html(self) -> None:
        resp = self.client.get("/")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("text/html", resp.headers["content-type"])
        self.assertIn("DEMO ENVIRONMENT", resp.text)
        self.assertIn("Truss Audit Proxy", resp.text)


class RootRouteFallback(ProxyBase):
    """Verify the root route falls back to a JSON pointer when no demo.html is configured."""

    def test_root_returns_json_pointer_when_unconfigured(self) -> None:
        # ProxyBase's create_app omits demo_html_path entirely.
        resp = self.client.get("/")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["see"], "/healthz")


class RetentionDays(ProxyBase):
    """retention_days request field should propagate to the receipt's retain_until."""

    canned_response = "fine"

    def test_retention_days_overrides_years_in_receipt(self) -> None:
        resp = self.client.post(
            "/v1/chat",
            json={
                "prompt": "What is the role of mitochondria?",
                "actor": _actor(),
                "retention_policy": "demo_seven_day",
                "retention_days": 7,
            },
        )
        self.assertEqual(resp.status_code, 200)
        receipt = self._read_receipt(resp.json()["receipt_path"])
        # retain_until should be ~7 days from now, not ~7 years.
        from datetime import datetime, timezone
        retain_until = datetime.fromisoformat(receipt["retention"]["retain_until"])
        delta_days = (retain_until.replace(tzinfo=timezone.utc) - datetime.now(timezone.utc)).days
        self.assertGreaterEqual(delta_days, 5)
        self.assertLessEqual(delta_days, 8)
        self.assertEqual(receipt["retention"]["retention_policy"], "demo_seven_day")


class Healthz(ProxyBase):
    def test_healthz_reports_policy_count_and_set_version(self) -> None:
        resp = self.client.get("/healthz")
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["status"], "ok")
        self.assertEqual(body["policy_count"], 4)
        self.assertNotEqual(body["policy_set_version"], "empty")
        self.assertEqual(body["model_id"], "stub-echo")


# ---------------------------------------------------------------------------
# Validation: missing actor field → 422 from FastAPI body validator
# ---------------------------------------------------------------------------


class RequestValidation(ProxyBase):
    def test_missing_actor_returns_422(self) -> None:
        resp = self.client.post("/v1/chat", json={"prompt": "hello"})
        self.assertEqual(resp.status_code, 422)

    def test_empty_prompt_returns_422(self) -> None:
        resp = self.client.post(
            "/v1/chat", json={"prompt": "", "actor": _actor()}
        )
        self.assertEqual(resp.status_code, 422)


# ---------------------------------------------------------------------------
# ChatGPT and Extension specific tests
# ---------------------------------------------------------------------------


class ExtensionCheckRoute(ProxyBase):
    """Verify the /v1/extension/check endpoint."""

    def test_benign_prompt_allowed(self) -> None:
        resp = self.client.post(
            "/v1/extension/check",
            json={
                "text": "Hello, how are you?",
                "direction": "prompt",
                "vendor": "chatgpt",
                "user_id": "test-user",
            }
        )
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["verdict"], "allowed")
        self.assertEqual(body["text"], "Hello, how are you?")
        self.assertIsNotNone(body["receipt_path"])

    def test_phi_prompt_blocked(self) -> None:
        resp = self.client.post(
            "/v1/extension/check",
            json={
                "text": "Patient lives at 1234 Main St.",
                "direction": "prompt",
                "vendor": "chatgpt",
                "user_id": "test-user",
            }
        )
        self.assertEqual(resp.status_code, 200)
        body = resp.json()
        self.assertEqual(body["verdict"], "blocked")
        self.assertIn("Patient address detected", body["block_message"])
        self.assertIsNotNone(body["receipt_path"])

    def test_browser_risk_accumulates_and_blocks(self) -> None:
        session_id = "sess_test_contextual"
        payload = {
            "session_id": session_id,
            "direction": "prompt",
            "event_type": "browser_prompt",
            "vendor": "chatgpt",
            "user_id": "test-user",
            "source": "pytest",
            "page_url": "https://chatgpt.com/c/demo",
            "text": "Patient DOB 1978-04-12.",
        }

        first = self.client.post(
            "/v1/extension/check",
            json={**payload, "event_id": "evt_one"},
        )
        self.assertEqual(first.status_code, 200)
        self.assertEqual(first.json()["verdict"], "allowed")
        first_receipt = self._read_receipt(first.json()["receipt_path"])
        self.assertEqual(first_receipt["contextual_policy"]["session_id"], session_id)
        self.assertEqual(
            first_receipt["contextual_policy"]["url"],
            "https://chatgpt.com/c/demo",
        )
        self.assertEqual(first_receipt["contextual_policy"]["source"], "pytest")
        self.assertEqual(
            first_receipt["contextual_policy"]["state_updates"][0]["key"],
            "risk_score",
        )

        second = self.client.post(
            "/v1/extension/check",
            json={**payload, "event_id": "evt_two"},
        )
        self.assertEqual(second.status_code, 200)
        self.assertEqual(second.json()["verdict"], "allowed")

        third = self.client.post(
            "/v1/extension/check",
            json={**payload, "event_id": "evt_three"},
        )
        self.assertEqual(third.status_code, 200)
        self.assertEqual(third.json()["verdict"], "blocked")
        self.assertIn("accumulated sensitive-data risk", third.json()["block_message"])

    def test_state_error_writes_error_decision_receipt(self) -> None:
        session_id = "sess_state_error"
        payload = {
            "session_id": session_id,
            "direction": "prompt",
            "event_type": "browser_prompt",
            "vendor": "chatgpt",
            "user_id": "test-user",
            "text": "Patient DOB 1978-04-12.",
        }
        first = self.client.post(
            "/v1/extension/check",
            json={**payload, "event_id": "evt_before_corrupt"},
        )
        self.assertEqual(first.status_code, 200)
        state_path = self.receipts_dir / "sessions" / f"{session_id}.json"
        data = json.loads(state_path.read_text())
        data["state"]["risk_score"] = "not numeric"
        state_path.write_text(json.dumps(data), encoding="utf-8")

        second = self.client.post(
            "/v1/extension/check",
            json={**payload, "event_id": "evt_after_corrupt"},
        )
        self.assertEqual(second.status_code, 200)
        self.assertEqual(second.json()["verdict"], "blocked")
        receipt = self._read_receipt(second.json()["receipt_path"])
        self.assertIn("state_error", receipt["contextual_policy"])
        error_decisions = [
            d for d in receipt["policy_decisions"] if d["enforcement_mode"] == "error"
        ]
        self.assertTrue(error_decisions)
        self.assertEqual(error_decisions[0]["error_reason"], "policy_eval_exception")


class ChatGPTCompletionsRoute(ProxyBase):
    """Verify the /v1/chat/completions endpoint (mocked upstream)."""

    def test_missing_auth_returns_401(self) -> None:
        resp = self.client.post(
            "/v1/chat/completions",
            json={
                "model": "gpt-4",
                "messages": [{"role": "user", "content": "Hello"}],
            }
        )
        self.assertEqual(resp.status_code, 401)


class ExtensionCheckWithBody(ProxyBase):
    """Verify that /v1/extension/check parses full JSON body payloads."""

    def test_chatgpt_web_body_allowed(self) -> None:
        body = {
            "messages": [
                {
                    "author": {"role": "user"},
                    "content": {"content_type": "text", "parts": ["Hello assistant, summarize this benign text."]}
                }
            ]
        }
        resp = self.client.post(
            "/v1/extension/check",
            json={
                "body": body,
                "direction": "prompt",
                "vendor": "chatgpt",
                "user_id": "test-user",
            }
        )
        self.assertEqual(resp.status_code, 200)
        res = resp.json()
        self.assertEqual(res["verdict"], "allowed")
        self.assertIsNone(res["mutated_body"])

    def test_chatgpt_web_body_blocked(self) -> None:
        body = {
            "messages": [
                {
                    "author": {"role": "user"},
                    "content": {"content_type": "text", "parts": ["Patient lives at 1234 Main St."]}
                }
            ]
        }
        resp = self.client.post(
            "/v1/extension/check",
            json={
                "body": body,
                "direction": "prompt",
                "vendor": "chatgpt",
                "user_id": "test-user",
            }
        )
        self.assertEqual(resp.status_code, 200)
        res = resp.json()
        self.assertEqual(res["verdict"], "blocked")
        self.assertIsNotNone(res["mock_response"])
        self.assertEqual(res["mock_response"]["message"]["author"]["role"], "assistant")

    def test_chatgpt_web_body_redacted(self) -> None:
        response_body = {
            "message": {
                "author": {"role": "assistant"},
                "content": {"content_type": "text", "parts": ["Patient's DOB: 1978-04-12."]}
            }
        }
        resp = self.client.post(
            "/v1/extension/check",
            json={
                "body": response_body,
                "direction": "response",
                "vendor": "chatgpt",
                "user_id": "test-user",
            }
        )
        self.assertEqual(resp.status_code, 200)
        res = resp.json()
        self.assertEqual(res["verdict"], "redacted")
        self.assertIsNotNone(res["mutated_body"])
        self.assertIn("[redacted]", res["mutated_body"]["message"]["content"]["parts"][0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
